<?php
header("Location: /~xlitvi02/IIS/frontend/index.php");
exit;